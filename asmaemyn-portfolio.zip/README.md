# Asmae Mouayn · Portfolio

Site statique (HTML, CSS, JavaScript), sans build ni dépendance.

## Structure

- `index.html` : contenu de la page (galerie, filtres, contact).
- `styles.css` : mise en page, thème clair et sombre automatique.
- `script.js` : filtres (mémorisés dans l'URL, ex. `/#photos`) et visionneuse plein écran (flèches ← →, Échap, balayage sur mobile).
- `images/` : chaque visuel existe en `.webp` (version servie), en `-900.webp` (version mobile, pour les grandes images) et en `.jpg` (secours pour les vieux navigateurs).
- `vercel.json` : cache des images et en-têtes de sécurité.

## Tester en local

```bash
npx serve .
```

## Déployer sur Vercel

1. vercel.com → Add New → Project → importer ce dépôt GitHub.
2. Framework Preset : **Other**. Pas de commande de build, dossier de sortie : racine.
3. Deploy. Chaque push sur `main` redéploie le site.

## Ajouter une image

1. Déposer le fichier dans `images/` (idéalement en `.webp` et `.jpg`, 1 800 px de large au plus).
2. Copier un bloc `<figure>` du bon groupe dans `index.html` et changer les chemins, le texte `alt`, `width`/`height` et `aspect-ratio` (largeur / hauteur de l'image).
