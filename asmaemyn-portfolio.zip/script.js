(function () {
  'use strict';

  /* Filters: show one group or all. The choice is kept in the URL hash (#rollups…). */
  var buttons = Array.prototype.slice.call(document.querySelectorAll('.filters button'));
  var groups = Array.prototype.slice.call(document.querySelectorAll('.group'));
  var keys = buttons.map(function (b) { return b.getAttribute('data-f'); });

  function applyFilter(f) {
    if (keys.indexOf(f) === -1) f = 'all';
    buttons.forEach(function (b) {
      b.setAttribute('aria-pressed', b.getAttribute('data-f') === f ? 'true' : 'false');
    });
    groups.forEach(function (g) {
      g.hidden = !(f === 'all' || g.getAttribute('data-g') === f);
    });
  }

  buttons.forEach(function (b) {
    b.addEventListener('click', function () {
      var f = b.getAttribute('data-f');
      applyFilter(f);
      var url = f === 'all' ? location.pathname + location.search : '#' + f;
      history.replaceState(null, '', url);
    });
  });
  applyFilter(location.hash.slice(1));

  /* Lightbox: click a work to see it full size, arrows to browse its group. */
  var dialog = document.querySelector('.lightbox');
  if (!dialog || typeof dialog.showModal !== 'function') return;
  var lbImg = dialog.querySelector('.lb-img');
  var lbCaption = dialog.querySelector('.lb-caption');
  var lbCount = dialog.querySelector('.lb-count');
  var prev = dialog.querySelector('.lb-prev');
  var next = dialog.querySelector('.lb-next');
  var items = [];
  var index = 0;
  var opener = null;

  function show(i) {
    index = (i + items.length) % items.length;
    var frame = items[index];
    var img = frame.querySelector('img');
    var fig = frame.closest('figure');
    var cap = fig && fig.querySelector('figcaption');
    lbImg.onerror = function () { lbImg.onerror = null; lbImg.src = frame.getAttribute('data-fallback'); };
    lbImg.src = frame.getAttribute('data-full');
    lbImg.alt = img ? img.alt : '';
    lbCaption.textContent = cap ? cap.textContent : '';
    lbCount.textContent = items.length > 1 ? (index + 1) + ' / ' + items.length : '';
    prev.hidden = next.hidden = items.length < 2;
  }

  document.querySelectorAll('.frame').forEach(function (frame) {
    frame.addEventListener('click', function () {
      var group = frame.closest('.group');
      items = Array.prototype.slice.call(group.querySelectorAll('.frame'));
      opener = frame;
      show(items.indexOf(frame));
      dialog.showModal();
    });
  });

  prev.addEventListener('click', function () { show(index - 1); });
  next.addEventListener('click', function () { show(index + 1); });
  dialog.querySelector('.lb-close').addEventListener('click', function () { dialog.close(); });

  dialog.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowLeft') { e.preventDefault(); show(index - 1); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); show(index + 1); }
  });

  /* Click on the dark background (outside the image and buttons) closes. */
  dialog.addEventListener('click', function (e) {
    if (e.target === dialog || e.target.classList.contains('lb-figure')) dialog.close();
  });

  dialog.addEventListener('close', function () {
    lbImg.removeAttribute('src');
    if (opener) opener.focus();
  });

  /* Swipe on touch screens. */
  var startX = null;
  dialog.addEventListener('touchstart', function (e) { startX = e.touches[0].clientX; }, { passive: true });
  dialog.addEventListener('touchend', function (e) {
    if (startX === null || items.length < 2) return;
    var dx = e.changedTouches[0].clientX - startX;
    if (Math.abs(dx) > 50) show(index + (dx < 0 ? 1 : -1));
    startX = null;
  });
})();
